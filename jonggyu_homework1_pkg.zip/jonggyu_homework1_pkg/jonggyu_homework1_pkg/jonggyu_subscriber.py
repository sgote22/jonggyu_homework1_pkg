import rclpy
from rclpy.node import Node
from std_msgs.msg import String

class JonggyuSubscriber(Node):
    def __init__(self):
        super().__init__('JonggyuSubscriber')
        self.subscription = self.create_subscription(
            String,
            'JonggyuTopic',
            self.listener_callback,
            10)
        self.subscription

    def listener_callback(self, msg):
        self.get_logger().info(f'I heard: "{msg.data}"')

def main(args=None):
    rclpy.init(args=args)
    jonggyu_subscriber = JonggyuSubscriber()
    rclpy.spin(jonggyu_subscriber)
    jonggyu_subscriber.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
