import rclpy
from rclpy.node import Node
from std_msgs.msg import String

class JonggyuPublisher(Node):
    def __init__(self):
        super().__init__('JonggyuPublisher')
        self.publisher_ = self.create_publisher(String, 'JonggyuTopic', 10)
        timer_period = 1.0  # 1초 주기
        self.timer = self.create_timer(timer_period, self.timer_callback)
        self.i = 0

    def timer_callback(self):
        msg = String()
        text_data = "ROS2_Data"
        int_data = self.i
        float_data = float(self.i) * 1.5
        
        msg.data = f"text: {text_data}, int: {int_data}, float: {float_data}"
        self.publisher_.publish(msg)
        self.get_logger().info(f'Publishing: "{msg.data}"')
        self.i += 1

def main(args=None):
    rclpy.init(args=args)
    jonggyu_publisher = JonggyuPublisher()
    rclpy.spin(jonggyu_publisher)
    jonggyu_publisher.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
