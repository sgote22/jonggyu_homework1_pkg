from setuptools import find_packages, setup

package_name = 'jonggyu_homework1_pkg'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='kangjun',
    maintainer_email='2201056@kunsan.ac.kr',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
   entry_points={
    'console_scripts': [
        'jonggyu_publisher = jonggyu_homework1_pkg.jonggyu_publisher:main',
        'jonggyu_subscriber = jonggyu_homework1_pkg.jonggyu_subscriber:main',
    	],
    },
)
